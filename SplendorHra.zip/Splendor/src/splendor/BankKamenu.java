/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package splendor;

/**
 *
 * @author Adam
 */
public class BankKamenu {
    int pocetZelKamenu;
    int pocetCerKamenu;
    int pocetHneKamenu;
    int pocetBilKamenu;
    int pocetModKamenu;
    int pocetZoliku;

    public BankKamenu(int pocetZelKamenu, int pocetCerKamenu, int pocetHneKamenu, int pocetBilKamenu, int pocetModKamenu, int pocetZoliku) {
        this.pocetZelKamenu = pocetZelKamenu;
        this.pocetCerKamenu = pocetCerKamenu;
        this.pocetHneKamenu = pocetHneKamenu;
        this.pocetBilKamenu = pocetBilKamenu;
        this.pocetModKamenu = pocetModKamenu;
        this.pocetZoliku = pocetZoliku;
    }


    
    
}
