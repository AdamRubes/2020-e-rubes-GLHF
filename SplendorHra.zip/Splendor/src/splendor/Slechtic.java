/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package splendor;

/**
 *
 * @author Adam
 */
public class Slechtic {
    int cenaB;
    int cenaM;
    int cenaC;
    int cenaZ;
    int cenaH;
    int pocetBodu = 3;
    String obrazek;
    boolean zabranej = false;

    public Slechtic(int cenaB, int cenaM, int cenaC, int cenaZ, int cenaH, String obrazek) {
        this.cenaB = cenaB;
        this.cenaM = cenaM;
        this.cenaC = cenaC;
        this.cenaZ = cenaZ;
        this.cenaH = cenaH;
        this.obrazek = obrazek;
    }

    
    
    
    
    
    
    
    
    
    
    
}


