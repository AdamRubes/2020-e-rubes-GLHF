/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package splendor;

/**
 *
 * @author Adam
 */
public class Karta {
    String barva;
    int body;
    int cenaB;
    int cenaM;
    int cenaC;
    int cenaH;
    int cenaZ;
    int kategorie;
    String obrazek;

    public Karta(String barva, int body, int cenaB, int cenaM, int cenaC, int cenaH, int cenaZ, int kategorie, String obrazek) {
        this.barva = barva;
        this.body = body;
        this.cenaB = cenaB;
        this.cenaM = cenaM;
        this.cenaC = cenaC;
        this.cenaH = cenaH;
        this.cenaZ = cenaZ;
        this.kategorie = kategorie;
        this.obrazek = obrazek;
    }
    
    
}

        
